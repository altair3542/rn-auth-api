import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Image, ScrollView } from 'react-native';
import { getProduct } from '../api';

export default function ProductDetailScreen({ route }) {
  const { id } = route.params;
  const [prod, setProd] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try { setProd(await getProduct(id)); } finally { setLoading(false); }
    })();
  }, [id]);

  if (loading) return <View style={styles.center}><ActivityIndicator /></View>;
  if (!prod) return <View style={styles.center}><Text>No encontrado</Text></View>;

  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.h1}>{prod.title}</Text>
      {prod.images?.[0] && (
        <Image
          source={{ uri: prod.images[0] }}
          style={{ width: '100%', height: 220, borderRadius: 12, marginVertical: 10 }}
          resizeMode="cover"
        />
      )}
      <Text style={styles.desc}>{prod.description}</Text>
      <Text style={styles.price}>Precio: ${prod.price}</Text>
      <Text style={styles.meta}>Categoría: {prod.category}</Text>
      <Text style={styles.meta}>Rating: {prod.rating}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  h1: { fontSize: 20, fontWeight: '800' },
  desc: { fontSize: 14, color: '#374151', marginVertical: 8 },
  price: { fontWeight: '800', marginTop: 4 },
  meta: { color: '#6b7280', marginTop: 4 },
});
