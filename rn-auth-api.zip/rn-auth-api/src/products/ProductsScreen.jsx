import { useContext, useEffect, useState } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, ActivityIndicator } from 'react-native';
import { getProducts } from '../api';
import { AuthContext } from '../auth/AuthContext';

export default function ProductsScreen({ navigation }) {
  const { user, signOut } = useContext(AuthContext);
  const [data, setData] = useState([]);
  const [skip, setSkip] = useState(0);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  const PAGE = 10;

  async function load(pageSkip = 0) {
    setLoading(true);
    try {
      const res = await getProducts({ limit: PAGE, skip: pageSkip });
      setData(res.products);
      setTotal(res.total);
      setSkip(res.skip);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(0); }, []);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.h1}>Productos</Text>
        <Pressable onPress={signOut}><Text style={styles.signout}>Salir</Text></Pressable>
      </View>

      {loading ? (
        <ActivityIndicator />
      ) : (
        <FlatList
          data={data}
          keyExtractor={(item) => String(item.id)}
          ItemSeparatorComponent={() => <View style={styles.sep} />}
          renderItem={({ item }) => (
            <Pressable onPress={() => navigation.navigate('ProductDetail', { id: item.id })} style={styles.item}>
              <Text style={styles.title}>{item.title}</Text>
              <Text numberOfLines={2} style={styles.desc}>{item.description}</Text>
              <Text style={styles.price}>${item.price}</Text>
            </Pressable>
          )}
          ListFooterComponent={() => (
            <View style={styles.pager}>
              <Pressable
                onPress={() => load(Math.max(0, skip - PAGE))}
                disabled={skip <= 0}
                style={[styles.pbtn, skip <= 0 && styles.pbtnDisabled]}
              >
                <Text>Anterior</Text>
              </Pressable>
              <Text style={styles.pinfo}>
                {Math.floor(skip / PAGE) + 1} / {Math.ceil(total / PAGE)}
              </Text>
              <Pressable
                onPress={() => load(skip + PAGE)}
                disabled={skip + PAGE >= total}
                style={[styles.pbtn, (skip + PAGE >= total) && styles.pbtnDisabled]}
              >
                <Text>Siguiente</Text>
              </Pressable>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  h1: { fontSize: 22, fontWeight: '800' },
  signout: { color: '#ef4444', fontWeight: '600' },
  sep: { height: 1, backgroundColor: '#e5e7eb' },
  item: { paddingVertical: 12 },
  title: { fontSize: 16, fontWeight: '700', marginBottom: 4 },
  desc: { fontSize: 12, color: '#6b7280', marginBottom: 6 },
  price: { fontSize: 13, fontWeight: '700' },
  pager: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 12, paddingVertical: 12 },
  pbtn: { paddingHorizontal: 10, paddingVertical: 6, backgroundColor: '#f3f4f6', borderRadius: 8 },
  pbtnDisabled: { opacity: 0.4 },
  pinfo: { marginHorizontal: 10 },
});
